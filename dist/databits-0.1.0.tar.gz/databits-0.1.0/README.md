Text Classifier using LSTM, GRU, and Transformer BERT
